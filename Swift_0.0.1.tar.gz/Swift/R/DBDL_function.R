#' Downloads refrence databases from NCBI
#' @param dbName the name of the NCBI BLAST database you'd like to install
#' @param path2db the full path to your blast database folder
#' @keywords database
#' @export
#' @examples
#' DBDL("est")
#'
DBDL <- function(dbName = "est", path2db = "./"){
  a <- getwd()
  setwd(path2db)
  system(command= paste("update_blastdb.pl --decompress", dbName,"[*]"))
  setwd(a)
  }
