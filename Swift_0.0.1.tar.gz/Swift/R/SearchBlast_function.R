#' Asks user to select file and specify its type
#' @param inputFile The name of the file containing your sequences to be blasted.
#' @param ResultsName the full desired name of your results file
#' @param databaseName the alisa of the NCBI database you will search
#' @param path2db the full path to your blast database folder
#' @keywords Search blast
#' @export
#' @examples
#'SearchBlast("testSequences.fa","ResultsFile.txt","est")
#'
SearchBlast <- function(inputFile = "testSequences.fa",ResultsName = "ResultsFile.txt", databaseName= "refseq_rna", path2db = "./"){
  a <- getwd()
  inputFile <- paste(a,inputFile, sep = "/")
  BlastresultsOut <- paste(a, ResultsName, sep = "/")
  setwd(path2db)
  blast.dir <- system(command = "which blastn", intern = TRUE)
  blast_out <- system(command = paste(
    blast.dir, "-db", databaseName,"-outfmt","'6 qseqid sacc qlen length slen pident nident qstart qend qcov evalue bitscore scomnames sskingdoms'", "-query",inputFile,"| sort -u >",BlastresultsOut),
    wait = TRUE)
  if(blast_out == 0){
    print("BLAST sucessfully completed")
  }else{print("BLAST search failed")}
  setwd(a)
}

