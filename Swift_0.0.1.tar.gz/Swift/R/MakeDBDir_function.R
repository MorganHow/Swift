#' creates a directory where databases will be stored
#' @param path2db Path where to create your database folder.
#' @param Name name of your database folder. Default: "blastdb"
#' @keywords databse direcotry
#' @export
#' @examples
#' MakeDBDir("./", "blastdb")
#'
MakeDBDir <- function(path2db = "./", Name="blastdb"){
  a <- getwd()
  setwd(path2db)
  dir.create(Name)
  path2db <<- paste(path2db, Name, sep = "/")
  setwd(a)
}
