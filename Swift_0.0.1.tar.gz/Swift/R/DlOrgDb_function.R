#' Will download Genbank accession numbers to entrez gene ID
#' @keywords Download Organisim Databases
#' @export
#' @examples
#'DlOrgDb()
#'
DlOrgDb <- function(){
  dbMap <- read.delim(paste0(path.package("Swift"), "/dbmap.txt"))
  dbMap <-unique.data.frame(dbMap, stringsAsFactors = FALSE)
  ##Install for Organism DB
  orgdbinstallnames <- as.character(dbMap$dbName)

  for (i in orgdbinstallnames){
    BiocManager::install(i)
  }
  lapply(orgdbinstallnames, require, character.only = TRUE)
}
